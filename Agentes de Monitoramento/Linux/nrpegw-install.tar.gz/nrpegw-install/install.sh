#!/bin/bash

BASEDIR=$(dirname "$0")
NRPEGW_PATH="/opt/nrpegw/"
NRPEGW_BIN="${NRPEGW_PATH}nrpe"
NRPEGW_SH="${NRPEGW_PATH}nrpegw.sh"
NRPEGW_CFG="${NRPEGW_PATH}nrpe.cfg"
SRC_PATH="${BASEDIR}/src"

# DETECTANDO VERSAO DO SO - INICIO
UNAME=`uname -a`
ISSUE=`cat /etc/issue 2>/dev/null`
RR=`cat /etc/redhat-release 2>/dev/null`
VERSION="${UNAME} ${ISSUE} ${RR}"

if [[ "$VERSION" =~ ^.*i686.*Debian\ GNU/Linux\ (5|6).*$ ]] || [[ "$VERSION" =~ ^.*i686.*GNU/Linux.*Ubuntu\ (9|10|11).*$ ]]; then #i686 - Debian 5/6 - Ubuntu 9/10/11
	TGZ="${SRC_PATH}/deb5_deb6.i686.tar.gz"
	CS="/etc/init.d/nrpegw start"
	Cs="/etc/init.d/nrpegw status"
elif [[ "$VERSION" =~ ^.*i686.*Debian\ GNU/Linux\ (7|8).*$ ]] || [[ "$VERSION" =~ ^.*i686.*GNU/Linux.*Ubuntu\ (12|13|14|15|16|17).*$ ]]; then #i686 - Debian 7/8 - Ubuntu 12/13/14/15/16/17
	TGZ="${SRC_PATH}/deb7_deb8.i686.tar.gz"
	CS="/etc/init.d/nrpegw start"
	Cs="/etc/init.d/nrpegw status"
elif [[ "$VERSION" =~ ^.*i686.*Debian\ GNU/Linux\ (9|10).*$ ]]; then #i686 - Debian 9/10
	TGZ="${SRC_PATH}/deb9_deb10.i686.tar.gz"
	CS="/etc/init.d/nrpegw start"
	Cs="/etc/init.d/nrpegw status"
elif [[ "$VERSION" =~ ^.*x86_64.*Debian\ GNU/Linux\ (5|6).*$ ]] || [[ "$VERSION" =~ ^.*x86_64.*GNU/Linux.*Ubuntu\ (9|10|11).*$ ]]; then #x86_64 - Debian 5/6 - Ubuntu 9/10/11
	TGZ="${SRC_PATH}/deb5_deb6.x86_64.tar.gz"
	CS="/etc/init.d/nrpegw start"
	Cs="/etc/init.d/nrpegw status"
elif [[ "$VERSION" =~ ^.*x86_64.*Debian\ GNU/Linux\ (7|8).*$ ]] || [[ "$VERSION" =~ ^.*x86_64.*GNU/Linux.*Ubuntu\ (12|13|14|15|16|17).*$ ]]; then #x86_64 - Debian 7/8 - Ubuntu 12/13/14/15/16/17
	TGZ="${SRC_PATH}/deb7_deb8.x86_64.tar.gz"
	CS="service nrpegw start"
	Cs="service nrpegw status"
elif [[ "$VERSION" =~ ^.*x86_64.*Debian\ GNU/Linux\ (9|10).*$ ]] || [[ "$VERSION" =~ ^.*x86_64.*GNU/Linux.*Ubuntu\ (18|19|20).*$ ]]; then #x86_64 - Debian 9/10 - Ubuntu 19/20
	TGZ="${SRC_PATH}/deb9_deb10.x86_64.tar.gz"
	CS="systemctl start nrpegw"
	Cs="systemctl status nrpegw"
elif [[ "$VERSION" =~ ^.*el(6).*i686.*$ ]]; then #i686 - el 6
	TGZ="${SRC_PATH}/el6.i686.tar.gz"; 
	CS="/etc/init.d/nrpegw start"
	Cs="/etc/init.d/nrpegw status"
elif [[ "$VERSION" =~ ^.*el(6).*x86_64.*$ ]]; then #x86_64 - el 6
	TGZ="${SRC_PATH}/el6.x86_64.tar.gz"; 
	CS="/etc/init.d/nrpegw start"
	Cs="/etc/init.d/nrpegw status"
elif [[ "$VERSION" =~ ^.*el(7).*x86_64.*$ ]] || [[ "$VERSION" =~ ^.*x86_64.*GNU/Linux.*Fedora\ release\ (27).*$ ]]; then #x86_64 - el 7 - Fedora 27
	TGZ="${SRC_PATH}/el7.x86_64.tar.gz"; 
	CS="systemctl start nrpegw"
	Cs="systemctl status nrpegw"
elif [[ "$VERSION" =~ ^.*el(8).*x86_64.*$ ]]; then #x86_64 - el 8
	TGZ="${SRC_PATH}/el8.x86_64.tar.gz"; 
	CS="systemctl start nrpegw"
	Cs="systemctl status nrpegw"
else 
	echo 'Versao Linux nao homologada! Entre em contato com a GroundWork: atendimento@groundwork.com.br.'; 
	exit; 
fi
# DETECTANDO VERSAO DO SO - FIM

# DEFININDO VARIAVEIS - INICIO
_continue='n'
while [[ "$_continue" != 'y' && "$_continue" != 'Y' && "$_continue" != 's' && "$_continue" != 'S' ]]
do
	echo ''
	echo '  ----------------------------------------'
	echo '  - VARIAVEIS DE CONFIGURACAO'
	echo '  ----------------------------------------'
	default_allowed_hosts='127.0.0.1'
	read -p "  Allowed Hosts (${default_allowed_hosts}): " allowed_hosts
	if [[ "$allowed_hosts" == "" ]]; then allowed_hosts=$default_allowed_hosts; fi
	default_nrpe_port='12482'
	read -p "  NRPE Port(${default_nrpe_port}): " nrpe_port
	if [[ "$nrpe_port" == "" ]]; then nrpe_port=$default_nrpe_port; fi
	default_plugins_path="${NRPEGW_PATH}plugins"
	read -p "  Plugins Path(${default_plugins_path}): " plugins_path
	if [[ "$plugins_path" == "" ]]; then plugins_path=$default_plugins_path; fi
	echo ''
	echo '  ----------------------------------------'
	echo '  - Valores definidos:'
        echo -e "  - Allowed Hosts:\033[32m ${allowed_hosts} \033[0m"
        echo -e "  - NRPE Port:\033[32m ${nrpe_port} \033[0m"
        echo -e "  - Plugins Path:\033[32m ${plugins_path} \033[0m"
	echo '  ----------------------------------------'
	echo ''	
	read -p "  Continuar? (y/n/r): " _continue
	if [[ "$_continue" == "n" || "$_continue" == "N" ]]; then echo '  Saindo..'; exit 2; fi
done
# DEFININDO VARIAVEIS - FIM

# INSTALANDO- INCIO
echo ''
echo '  ----------------------------------------'
echo '  - INSTALANDO'
echo '  ----------------------------------------'
T='Criando diretorio..';echo -e "\033[33m${T}\033[0m"
mkdir -p "${NRPEGW_PATH}"
mkdir -p "${NRPEGW_PATH}/tmp"
T='Extraindo aquivos..';echo -e "\033[33m${T}\033[0m"
tar -zxvf $TGZ --directory "${NRPEGW_PATH}"
T='Montando cfg..';echo -e "\033[33m${T}\033[0m"
CFG_DEFAULT="${SRC_PATH}/nrpe.default.cfg"
cat "${CFG_DEFAULT}" > "${CFG_DEFAULT}.tmp"
cat "${CFG_DEFAULT}.tmp" | sed "s/{NRPE-ALLOWED-HOSTS}/${allowed_hosts}/" | sed "s/{NRPE-PORT}/${nrpe_port}/" | sed -e "s|{PATH-PLUGINS}|${plugins_path}|g" > "${NRPEGW_CFG}"
rm -f "${CFG_DEFAULT}.tmp"
T='Copiando arquivos..';echo -e "\033[33m${T}\033[0m"
echo "${SRC_PATH}/nrpegw.sh"
yes | cp -Ra "${SRC_PATH}/nrpegw.sh" "${NRPEGW_SH}"
ListOfFiles=`ls -1p "${SRC_PATH}/common/" 2>/dev/null`
if [ $? -eq 0 ]; then
	while read -r fPlugin
	do	
		echo ${fPlugin}
		yes | cp -Ra "${SRC_PATH}/common/${fPlugin}" "${NRPEGW_PATH}plugins/"
	done <<<"${ListOfFiles}"
fi
T='Ajustando usuario..';echo -e "\033[33m${T}\033[0m"
useradd=`whereis useradd | awk {'print $2'}`
$useradd -s /sbin/nologin nagios
chown=`whereis chown | awk '{print $2}'`
$chown -R nagios:nagios /opt/nrpegw
T='Configurando servico..';echo -e "\033[33m${T}\033[0m"
"${NRPEGW_PATH}cfg-auto-start.sh"
rm -f "${NRPEGW_PATH}cfg-auto-start.sh"
T='Iniciando o NRPEGW..';echo -e "\033[33m${T}\033[0m"
echo ''
mv "${NRPEGW_BIN}" "${NRPEGW_BIN}.bin"
$CS
$Cs

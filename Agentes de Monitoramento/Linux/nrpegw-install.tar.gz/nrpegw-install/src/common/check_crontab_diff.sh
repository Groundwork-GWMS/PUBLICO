#!/bin/bash

SCRIPT=`basename "$0"`
SESSION="/opt/nrpegw/tmp/$SCRIPT.SESSION"
CACHE="/opt/nrpegw/tmp/$SCRIPT.CACHE"
TMP="/opt/nrpegw/tmp/$SCRIPT.TMP"
WTIME="/opt/nrpegw/tmp/$SCRIPT.WTIME"

rm -f "$TMP"

EXPIRE_WARNING_TIME=$(($1*60*60))

O=`for user in $(cut -f1 -d: /etc/passwd | grep -v $USER); do sudo crontab -u $user -l 2>&1 | sed "s/^/$user: /"; done; crontab -l | sed "s/^/$USER: /" ;`

if [[ "$O" == "" ]]; then
        echo "Erro ao obter crontab dos usuarios."
        exit 1
fi

if [[ ! -e "$CACHE" ]]; then
        echo "Cache in creation.."
        echo -e "$O" > "$CACHE"
        exit 3
else
        echo -e "$O" > "$TMP"
fi

DIFF=`diff "$CACHE" "$TMP"`
if [[ "$DIFF" != "" ]]; then
        if [[ ! -e "$WTIME" ]]; then
                date +'%s' > "$WTIME"
        else
                WARNING_TIME=`cat "$WTIME" | xargs`
                CURRENT_TIME=`date +'%s'`
                DIFF_TIME=$(( $CURRENT_TIME - $WARNING_TIME ))
                if [ $DIFF_TIME -ge $EXPIRE_WARNING_TIME ]; then
                        echo 'OK - Atualizando output do crontab no arquivo de cache.'
                        echo -e "$O" > "$CACHE"
                        rm -f "$WTIME"
                        exit 0
                fi
        fi
        echo "CRITICAL - A lista do crontab esta diferente do arquivo de cache.<br>Desc:$DIFF" | sed ':a;N;$!ba;s/\n/<br>/g' | sed 's/|/-/g'
        exit 2
else
        echo "OK - A lista do crontab esta igual ao arquivo de cache."
        exit 0
fi


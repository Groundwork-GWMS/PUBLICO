#!/bin/bash
re='^[0-9]+$'
if [ $1 ] && [[ $2 =~ $re ]] && [[ $3 =~ $re ]]; then
	process=$1
	memWarning=$2
	memCritical=$3

	processes=`ps -eo "%c;" -o rss -o ";%a" | grep -w "$process" | grep -v "^grep" | grep -v "$0"`
	
	totalProcess=0
	totalMemory=0

	while read -r line
	do
		if [[ "$line" != "" ]]; then
			tmpMem=`echo $line | cut -d ';' -f 2 | sed 's/ //g'`
			if [[ $tmpMem =~ $re ]]; then
				totalMemory=$(($totalMemory+$tmpMem))					
			fi
			totalProcess=$(($totalProcess+1))		
		fi
	done <<<"$processes"

	if [ $totalProcess -eq 0 ]; then

		out="${totalProcess} process active ( '$process':Stopped RAM:${totalMemory}MB )"
		perf="'memory'=${totalMemory}MB;$memWarning;$memCritical 'num_process'=${totalProcess};0;0"
	        echo "CRITICAL - $out|$perf"
	        exit 2
	else

		totalMemory=`awk "BEGIN {print $totalMemory/1024 }"`
		totalMemory=`printf "%0.2f\n" $totalMemory`
		totalMemoryI=`echo ${totalMemory%.*}`

		out="${totalProcess} process active ( '$process':Started RAM:${totalMemory}MB )"
		perf="'memory'=${totalMemory}MB;$memWarning;$memCritical 'num_process'=${totalProcess};0;0"
	
		if [ "$memWarning" -eq 0 ] && [ "$memCritical" -eq 0 ]; then
		        echo "OK - $out|$perf"
		        exit 0
		elif [ "$totalMemoryI" -ge "$memCritical" ]; then
		        echo "CRITICAL - $out|$perf"
		        exit 2
		elif [ "$totalMemoryI" -ge "$memWarning" ]; then
		        echo "WARNING - $out|$perf"
		        exit 1
		else
		        echo "OK - $out|$perf"
		        exit 0
		fi	
	fi
else
    echo "check_proc_mem v1.0"
    echo ""
    echo "Usage:"
    echo "check_proc_mem.sh <warn_MB> <criti_MB> <process_pattern_argument>"
    echo ""
    echo "Below: If tomcat use more than 1024MB resident memory, send warning"
    echo "check_proc_mem.sh 1024 2048 mysqld"
    echo ""
    exit 3
fi
## File - check_proc_mem.sh ends

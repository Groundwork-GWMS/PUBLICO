#!/bin/bash
#########
strUrl=''
strPath=''
strFile=''
strOpt=''
intCurlTimeout=10
for a in "$@"
do
        if [[ "$a" =~ ^/url:.*$ ]]; then
                strUrl=`echo $a | sed "s|^/url:||g"`
        elif [[ "$a" =~ ^/path:.*$ ]]; then
                strPath=`echo $a | sed "s|^/path:||g"`
        elif [[ "$a" =~ ^/file:.*+$ ]]; then
                strFile=`echo $a | sed "s|^/file:||g"`
        elif [[ "$a" =~ ^/opt:.*+$ ]]; then
                strOpt=`echo $a | sed "s|^/opt:||g"`
        elif [[ "$a" =~ ^/curl_timeout:[0-9]+$ ]]; then
                intCurlTimeout=`echo $a | sed "s|^/curl_timeout:||g"`
        fi
done

lb=","
if [ -z "$strUrl" ] || [ -z "$strPath" ] || [ -z "$strFile" ] || [ -z "$strOpt" ] || [ -z "$intCurlTimeout" ]; then
	exit 3
fi
strUrl="${strUrl}/update.php"
strPath=`echo "${strPath}" | sed '$ s/\/$//g'`
strPathToOut=`echo "${strPath}" | sed 's/\\\\/\//g'`
strFileToOut=`echo "${strFile}" | sed 's/\\\\/\//g'`

strScriptDir=`dirname "$0"`
cCurl="`dirname $strScriptDir`/curl/bin/curl"
if [ `whereis curl | cut -d ':' -f 2 | wc -w` -lt 1 ]; then
        if [ ! -x $cCurl ]; then
                echo "curl not found on this server! $strDiscoveryIp"
                exit 2
        else
                curl=$cCurl
        fi
else
        curl='curl'
fi

if [[ "$strPath" != './'* && "$strPath" != *"nrpegw"* ]]; then
	echo "WARNING - (Erro) Operacao nao permitida."
	exit 1
fi
if [[ "$strFile" == "*ALL*" ]]; then

	strOutput=''
	strOutput_MD5LocalError=''
	strOutput_MD5LocalNewError=''
	strOutput_MD5RemoteError=''
	strOutput_FilesRemoteNotExist=''
	strOutput_SuccessUpdate=''
	strOutput_ErrorUpdate=''
	strOutput_OkUpdated=''
	isWARNING=0

	#ATUALIZA TODOS OS ARQUIVOS DO DIRETORIO INFORMADO
	if [ -d "${strPath}" ]; then	

		ListOfFiles=`ls -1p "${strPath}/" 2>/dev/null`
		if [ $? -ne 0 ]; then
			echo "WARNING - (Erro) ao obter a lista de arquivos do diretorio (${strPathToOut})."
			exit 1
		fi
		
		while read -r tmpFile
		do
		
			if ! [[ "$tmpFile" =~ ^.*\.bkp\.[0-9]+-[0-9]+$ ]]; then

				tmpFile=`echo "${tmpFile}" | sed 's/\\\\/\//g'`
				tmpFileToOut=`echo "${tmpFile}" | sed 's/\\\\/\//g'`

				#AJUSTA VARIAVEIS
				strFullPathFile="${strPath}/${tmpFile}"
				strFullPathFileTmp="${strFullPathFile}.temp"
				strFullPathFileBkp="${strFullPathFile}.bkp.`date +'%y%m%d-%H%M%S'`"
				md5Local=''
				md5Remote=''

				if [ -f "${strFullPathFile}" ]; then
					md5Local=`md5sum "${strFullPathFile}" 2>/dev/null | awk '{ print $1 }'`	
					if [[ "$md5Local" == "" ]]; then
						strOutput_MD5LocalError="${strOutput_MD5LocalError}${lb}${tmpFileToOut}"
						isWARNING=1
					fi
					md5Local=`echo ${md5Local} | awk '{ print toupper($0) }'`
				fi
			
				#REMOVE O ARQUIVO DE SAIDA TEMPORARIO CASO EXISTA
				if [ -f "${strFullPathFileTmp}" ]; then
					rm -f "${strFullPathFileTmp}"
				fi

				#OBTEM O MD5 DO ARQUIVO REMOTO.
				R=`"${curl}" --connect-timeout $intCurlTimeout --max-time $intCurlTimeout -s -k "${strUrl}?opt=${strOpt}&file=${tmpFile}&getMd5=1" 2>/dev/null`
				if [[ "$R" == "" ]]; then
					strOutput_MD5RemoteError="${strOutput_MD5RemoteError}${lb}${tmpFileToOut}"	
					isWARNING=1
				fi
				if [[ "$R" == "FILE_NOT_FOUND" ]]; then
					strOutput_FilesRemoteNotExist="${strOutput_FilesRemoteNotExist}${lb}${tmpFileToOut}"
					isWARNING=1
				else
					md5Remote=`echo ${R} | awk '{ print toupper($0) }'`
				fi
				#OBTEM ARQUIVO REMOTO - INICIO
				if [[ "$md5Remote" != "" ]]; then

					#BAIXA O ARQUIVO SOMENTE SE OS MD5 FOREM DIFERENTES
					if [[ "$md5Remote" != "$md5Local" ]]; then

						"${curl}" --connect-timeout $intCurlTimeout --max-time $intCurlTimeout -s -k --output "${strFullPathFileTmp}" "${strUrl}?opt=${strOpt}&file=${tmpFile}&getFile=1" /dev/null 2>&1
						if [ -f "${strFullPathFileTmp}" ]; then

							#FAZ BACKUP DO ARQUIVO ATUAL CASO EXISTA
							if [[ "$md5Local" != "" ]]; then
								mv "${strFullPathFile}" "${strFullPathFileBkp}"
							fi

							#AJUSTA O NOME DO NOVO ARQUIVO BAIXADO
							mv "${strFullPathFileTmp}" "${strFullPathFile}"

							#OBTEM MD5 DO ARQUIVO LOCAL CASO ELE EXISTA
							newMd5Local=''
							if [ -f "${strFullPathFile}" ]; then
								newMd5Local=`md5sum "${strFullPathFile}" 2>/dev/null | awk '{ print $1 }'`
								if [[ "$md5Local" == "" ]]; then
									strOutput_MD5LocalNewError="${strOutput_MD5LocalNewError}${lb}${tmpFileToOut}"
									isWARNING=1
								fi
								newMd5Local=`echo ${md5Local} | awk '{ print toupper($0) }'`
							fi

							if [[ "$newMd5Local" != "$md5Remote" ]]; then
								strOutput_SuccessUpdate="${strOutput_SuccessUpdate}${lb}${tmpFileToOut}"
							else
								strOutput_ErrorUpdate="${strOutput_ErrorUpdate}${lb}${tmpFileToOut}"
								isWARNING=1
							fi

						else
							strOutput_ErrorUpdate="${strOutput_ErrorUpdate}${lb}${tmpFileToOut}"
							isWARNING=1
						fi
					else
						strOutput_OkUpdated="${strOutput_OkUpdated}${lb}${tmpFileToOut}"
					fi				
				fi
			

			fi
		done <<<"${ListOfFiles}"
		
	else
		echo "WARNING - Diretorio (${strPathToOut}) nao encontrado."
		exit 1
	fi

	if [ -z "$strOutput_MD5LocalError" ] || [ -z "$strOutput_MD5LocalNewError" ] || [ -z "$strOutput_MD5RemoteError" ] || [ -z "$strOutput_FilesRemoteNotExist" ] || [ -z "$strOutput_SuccessUpdate" ] || [ -z "$strOutput_ErrorUpdate" ] || [ -z "$strOutput_OkUpdated" ]; then

		if [[ "$trOutput_MD5LocalError" != "" ]]; then strOutput="${strOutput}#Erro MD5 arquivo local:${strOutput_MD5LocalError}${lb}"; fi
		if [[ "$strOutput_MD5LocalNewError" != "" ]]; then strOutput="${strOutput}#Erro MD5 novo arquivo local:${strOutput_MD5LocalNewError}${lb}"; fi
		if [[ "$strOutput_MD5RemoteError" != "" ]]; then strOutput="${strOutput}${lb}#Erro MD5 arquivo remoto:${strOutput_MD5RemoteError}${lb}"; fi
		if [[ "$strOutput_FilesRemoteNotExist" != "" ]]; then strOutput="${strOutput}#Arquivo remoto nao existe:${strOutput_FilesRemoteNotExist}${lb}"; fi
		if [[ "$strOutput_SuccessUpdate" != "" ]]; then strOutput="${strOutput}#Sucesso ao atualizar:${strOutput_SuccessUpdate}${lb}"; fi
		if [[ "$strOutput_OkUpdated" != "" ]]; then strOutput="${strOutput}#Ja atualizado:${strOutput_OkUpdated}${lb}"; fi
		if [[ "$strOutput_ErrorUpdated" != "" ]]; then strOutput="${strOutput}#Erro ao atualizar:${strOutput_ErrorUpdate}${lb}"; fi
	
		echo "${strOutput}"
		if [ $isWARNING -eq 1 ]; then
			exit 1
		else
			exit 0
		fi
	else
		echo "OK - Nenhum arquivo para atualizar."
		exit 0
	fi

else

	#AJUSTA VARIAVEIS
	strFullPathFile="${strPath}/${strFile}"
	strFullPathFileTmp="${strFullPathFile}.temp"
	strFullPathFileBkp="${strFullPathFile}.bkp.`date +'%y%m%d-%H%M%S'`"
	md5Local=''
	md5Remote=''

	#OBTEM MD5 DO ARQUIVO LOCAL CASO ELE EXISTA
	if [ -f "${strFullPathFile}" ]; then
		md5Local=`md5sum "${strFullPathFile}" 2>/dev/null | awk '{ print $1 }'`
		if [[ "$md5Local" == "" ]]; then
			echo "WARNING - (Erro) ao obter MD5 do arquivo local (${strFileToOut})."
			exit 1
		fi
		md5Local=`echo ${md5Local} | awk '{ print toupper($0) }'`
	fi

	#REMOVE O ARQUIVO DE SAIDA TEMPORARIO CASO EXISTA
	if [ -f "${strFullPathFileTmp}" ]; then
		rm -f "${strFullPathFileTmp}"
	fi

	#OBTEM O MD5 DO ARQUIVO REMOTO.	
	R=`${curl} --connect-timeout $intCurlTimeout --max-time $intCurlTimeout -s -k "${strUrl}?opt=${strOpt}&file=${strFile}&getMd5=1" 2>/dev/null`
	if [[ "$R" == "" ]]; then
		echo "WARNING - (Erro) ao obter MD5 do arquivo remoto (${strFileToOut})."
		exit 1
	fi
	if [[ "$R" == "FILE_NOT_FOUND" ]]; then
		echo "WARNING - Arquivo remoto (${strFileToOut}) nao existe."
		exit 1
	else
		md5Remote=`echo ${R} | awk '{ print toupper($0) }'`
	fi
	
	#OBTEM ARQUIVO REMOTO
	if [[ "$md5Remote" != "" ]]; then

		#BAIXA O ARQUIVO SOMENTE SE OS MD5 FOREM DIFERENTES
		if [[ "$md5Remote" != "$md5Local" ]]; then

			${curl} --connect-timeout $intCurlTimeout --max-time $intCurlTimeout -s -k  --output "${strFullPathFileTmp}" "${strUrl}?opt=${strOpt}&file=${strFile}&getFile=1" > /dev/null 2>&1
			if [ -f "${strFullPathFileTmp}" ]; then

				#FAZ BACKUP DO ARQUIVO ATUAL CASO EXISTA			
				if [[ "$md5Local" != "" ]]; then
					mv "${strFullPathFile}" "${strFullPathFileBkp}"
				fi

				#AJUSTA O NOME DO NOVO ARQUIVO BAIXADO
				mv "${strFullPathFileTmp}" "${strFullPathFile}"
				chmod 755 "${strFullPathFile}"

				#OBTEM MD5 DO ARQUIVO LOCAL CASO ELE EXISTA
				newMd5Local=''
				if [ -f "${strFullPathFile}" ]; then
					newMd5Local=`md5sum "${strFullPathFile}" 2>/dev/null | awk '{ print $1 }'`
					if [[ "$newMd5Local" == "" ]]; then
						echo "WARNING - (Erro) ao obter MD5 do NOVO arquivo local (${strFileToOut}) no caminho (${strPathToOut})."
						exit 1
					fi
					newMd5Local=`echo ${md5Local} | awk '{ print toupper($0) }'`
				fi

				if [[ "$newMd5Local" != "$md5Remote" ]]; then
					echo "OK - Sucesso ao atualizar o arquivo (${strFileToOut}) no caminho (${strPathToOut})."
					exit 0
				else
					echo "WARNING - (Erro) Erro ao atualizar o arquivo (${strFileToOut}) no caminho (${strPathToOut})."
					exit 1
				fi


			else
				echo "WARNING - (Erro) Erro ao baixar o novo arquivo (${strFileToOut})."
				exit 1
			fi
		else
			echo "OK - O arquivo (${strFileToOut}) no caminho (${strPathToOut}) ja esta atualizado."
			exit 0
		fi
	fi
fi

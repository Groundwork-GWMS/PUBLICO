#!/bin/bash
/opt/nrpegw/nrpegw.sh restart > /dev/null 2>&1
if [ $? -eq 0 ]; then
	echo "O restart do servico (nrpegw) foi executado com sucesso."
	exit 0
else
	echo "O restart do servico (nrpegw) falhou."
	exit 2
fi

#!/bin/bash
#
# nrpegw      Start nrpegw agent
# chkconfig: 2345 99 01

### BEGIN INIT INFO
# Provides:          nrpegw
# Required-Start:
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Starts, stops and restart nrpegw agent
# Description:       Starts, stops and restart nrpwgw agent
### END INIT INFO

BIN="/opt/nrpegw/nrpe.bin"
CFG="/opt/nrpegw/nrpe.cfg"

function showSpecs(){
  echo ""
  echo "     NRPE BIN : $BIN"
  echo "     NRPE CFG : $CFG"
  echo ""
}

function checkRunning(){
  PID=`ps -ef | grep "${BIN}" | grep -v "grep ${BIN}" | awk '{print $2}'`
  if [[ "$PID" == "" ]]; then
    echo -e "\033[31m Error \033[0m"
    e=2
  else
    echo -e "\033[32m OK \033[0m"
    e=0
  fi
}

function checkStatus(){
  PID=`ps -ef | grep "${BIN}" | grep -v "grep ${BIN}" | awk '{print $2}'`
  if [[ "$PID" == "" ]]; then
    echo -e "\033[31m Error \033[0m[ ${BIN} ] Not Running!"
    e=2
  else
    echo -e "\033[32m OK \033[0m[ ${BIN} ] is Running! (Pid ${PID})"
    e=0
  fi
}

function checkStopped(){
  PID=`ps -ef | grep "${BIN}" | grep -v "grep ${BIN}" | awk '{print $2}'`
  if [[ "$PID" == "" ]]; then
    echo -e "\033[32m OK \033[0m"
  else
    echo -e "\033[31m Error \033[0m"
  fi
}

function Start(){
  echo "Starting.. "
  $BIN -c $CFG -d -4 2> /dev/null
  sleep 1
}

function Stop(){
  echo "Stopping.. "
  PID=`ps -ef | grep "${BIN}" | grep -v "grep ${BIN}" | awk '{print $2}'`
  if [[ "$PID" != "" ]]; then
    kill $PID
    sleep 1
  fi
}

case "$1" in
  start)
  showSpecs
  Start
  checkRunning
  exit $e
  ;;
  stop)
  showSpecs
  Stop
  checkStopped
  ;;
  restart)
  showSpecs
  Stop
  checkStopped
  Start
  checkRunning
  exit $e
  ;;
  status)
  checkStatus
  exit $e
  ;;
  *)
  echo "Usage: $0 start/stop/restart"
  exit 3
  ;;
esac
echo ""
exit 0
